#Some Design Decisions

1. in arith.P, I have allowed a unary '-' being applied on a negative number. It negates the value of the negative number so essentially it makes it positive.

for example, if arith([-2,-2]). is called, then the output will give 2 solutions
	1. -2=-2
	2. --2=--2
nothing on this was mentioned so I took this decision to allow it.

